<template>
    <div>

        <!-- 搜索栏 -->
        <div class="top-search" style="display:none; text-align: center">
            <el-input style="margin: 40px auto; margin-bottom:10px; width:50%;" placeholder="请输入内容"   v-model="search" class="input-with-select">
                
                <el-button slot="append" @click="goSearch()" icon="el-icon-search"></el-button>
            </el-input>
        </div>

        <!-- 查询城市 -->
        <div style="overflow:hidden;display:none;">
            <el-form :inline="true" ref="formInline" :model="formInline" class="demo-form-inline" style="float:right;margin-right:0.5%">

            <el-form-item class="formCity" label="城市选择：" prop="cityV" >
                <el-select
                v-model="formInline.cityV"
                @change="goSearch()"
                filterable
                allow-create
                
                placeholder="请选择文章标签">
                    <el-option
                    v-for="item in cityList"
                    :key="item.id"
                    :label="item.provinceName"
                    :value="item.id">
                    </el-option>
                </el-select>
            </el-form-item>

        </el-form>
        
        </div>
        

        <!-- 批量删除 -->
        <div  class="button-add" style=" display:flex;  justify-content: space-between; overflow: hidden; margin-top:20px; margin-left:2%;">
            <el-button  style=" margin-right:5%;margin-bottom:20px" type="primary"  @click="deletMost()">批量删除</el-button>  
            <el-button  style=" margin-right:2%;margin-bottom:20px" type="primary"  @click="addMost()">新增</el-button>  
        </div>

        <el-table
            :data="tableList"
            tooltip-effect="dark"
            style="width: 96%;margin:0 auto"
            border
            :header-cell-style="{background:'#EEF1F6'}"
            size="small"
            @selection-change="handleSelectionChange">
            <el-table-column
            type="selection"
           >
            </el-table-column>
           <el-table-column
            type="index"
            >
            </el-table-column>

           


            <el-table-column
            prop="dateTime"
            label="创建时间"
            show-overflow-tooltip>
            </el-table-column>

            <el-table-column
            style="position:relative"
            prop="bannerUrl"
            label="显示图片"
            width="110px"
            show-overflow-tooltip>
                <template    slot-scope="scope">            
                    <div title="点击显示大图" >
                        <img :src="qiniu.showUrl+scope.row.imgName"    style="width:60px; height:20px" />
                        <el-popover
                        placement="right"
                        trigger="click"
                        >
                            <img :src="qiniu.showUrl+scope.row.imgName"    style="max-height:400px" />
                            <i slot="reference"  class="el-icon-view" style="font-size:16px"></i>
                        </el-popover>
                    </div>
                </template>  

            </el-table-column>




            <el-table-column
            fixed="right"
            label="操作"
            width="300px"
           >
            <template slot-scope="scope">



                <el-button
                @click.native.prevent="deleteRow(scope.$index, tableList)"
                type="danger"
                size="small">
                删除
                </el-button>
                

                <el-button
                @click.native.prevent="changeRow(scope.$index, tableList)"
                type="success"
                size="small">
                修改
                </el-button>

                <el-button
                @click.native.prevent="showDetail(scope.$index, tableList)"
                type="success"
                size="small">
                查看详情
                </el-button>
                

            </template>
            </el-table-column>
        </el-table>

        <!-- 分页 -->
          <div class="block" style="overflow:hidden;">

                <el-pagination
                style="float:right; margin-right:10%"
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current-page="currentPage"
                :page-sizes="navigatepageNums"
                :page-size="10"
                layout="total, prev, pager, next, jumper"
                :total="total"
                >
                </el-pagination>
            </div>


            <!-- 弹窗 -->
            <el-dialog
            title="上传"
            :visible.sync="dialogVisible"
            width="60%"
            @close="closeDialog"
            :modal-append-to-body='false'
            :close-on-click-modal="false"
            center>


            <el-upload
                :data="qiniu"
                :limit="1"
                style="margin-left:3%;margin-right:4%;margin-bottom:10px"
                class="upload-demo"
                ref="uploadimg"
                action="http://upload.qiniup.com"
                list-type="picture"
                :on-success="updateDetailSuccess"
                :file-list="upfileList"
                :on-change="handleChange"
                :before-upload="beforeUpload"
                :auto-upload="false">
                <el-button slot="trigger" size="small" type="primary">选取文件</el-button>

            </el-upload>
            <div style="display:flex;margin-left:3%">
                <el-button style="margin-left:0;width:100%;margin-right:4%" slot="trigger" size="small" type="primary" @click="subPicForm">提交</el-button>
            </div>
        
        </el-dialog>  


        <!-- 弹窗2 -->
            <el-dialog
            title="上传"
            :visible.sync="dialogVisible2"
            width="60%"

            center>

            <div style="text-align: center">{{submitTag2=="add" ? '当前为增加': "当前为修改"}}</div>
            
            <el-button style="float:right;" size="small" type="primary" v-show="submitTag2=='add' ? false: true" @click="switcher()">{{"切换到增加"}}</el-button>
            <el-upload
                :data="qiniu"
                :limit="6"
                multiple
                class="upload-demo"
                ref="uploadimg2"
                action="http://upload.qiniup.com"
                list-type="picture"
                :on-success="updateDetailSuccess2"
                :file-list="upfileList2"
                :on-change="handleChange2"
                :before-upload="beforeUpload"
                :auto-upload="false">
                <el-button slot="trigger" size="small" type="primary" style="margin-bottom:10px" >选取文件</el-button>
                

            </el-upload>
            
            <div style="display:flex">
                <el-button style="margin-left:0;width:100%;" slot="trigger" size="small" type="primary" @click="subDetailForm">提交</el-button>
            </div>

            <div style="width:100%;margin-top:10px">
                <el-button   style="margin-left:0;" slot="trigger" size="small" type="primary" @click="deletAll2()">
                    批量删除
                </el-button>

                
                <el-table

                    :data="tableList2"
                    tooltip-effect="dark"
                    style="margin-right:50px"
                    border
                    :header-cell-style="{background:'#EEF1F6'}"
                    size="small"
                    @selection-change="handleSelectionChange2">

                    <el-table-column
                    type="selection"

                    :key='Math.random()'
                    >
                    </el-table-column>
                    <el-table-column
                    type="index"
                    >
                    </el-table-column>

                


                    

                    
                    <el-table-column
                    style="position:relative"
                    prop="pictureUrl"
                    label="显示图片"

                    show-overflow-tooltip>
                        <template    slot-scope="scope">            
                            <div title="点击显示大图"  >
                                <img :src="qiniu.showUrl+scope.row.imgName"    style="width:60px; height:20px" />
                                <el-popover
                                placement="right"
                                trigger="click"
                                >
                                    <img :src="qiniu.showUrl+scope.row.imgName"    style="max-height:400px" />
                                    <i slot="reference"  class="el-icon-view" style="font-size:16px"></i>
                                </el-popover>
                            </div>
                        </template>  

                    </el-table-column>



                    
                    <el-table-column
                    prop="dateTime"
                    label="创建时间"
                    show-overflow-tooltip>
                    </el-table-column>





                    <el-table-column
                    fixed="right"
                    label="操作"

                    >
                    <template slot-scope="scope">



                        <el-button
                        @click.native.prevent="deleteDetailRow(scope.$index, tableList2)"
                        type="danger"
                        size="small">
                        删除
                        </el-button>
                        

                        <el-button
                        @click.native.prevent="changeDetail(scope.$index, tableList2)"
                        type="success"
                        size="small">
                        修改
                        </el-button>

                    </template>
                    </el-table-column>

                    </el-table>
            </div>
        
        </el-dialog>  
    </div>
</template>

<script>

import url from '../../utils/url';
import {getCookie,getErr} from '../../utils/utils';
import {postRequest,uploadFileRequest} from '../../utils/api';
export default {
    data(){

        return {
            submitTag:"add",
            submitTag2:"add",


            upfileList:[],
            upfileList2:[],
            file:"",
            qiniu:{
                upUrl:'',
                token:'',
                showUrl:''
            },
            uploadNum:0,
            imgListLength:'',
            isChangeImg:false,

            uploadNum2:0,
            imgListLength2:'',
            isChangeImg2:false,

            tableList:[],
            tableList2:[],

            formInline:{
                cityV:""
            },

            dialogVisible:false,
            dialogVisible2:false,
            search:"",
            currentPage: 1,
            navigatepageNums:[],
            cityList:[],
            total:1,
            changeId:"",//中间变化的ID
            changeIndex:"",
        }
    },
    methods:{

        switcher (){
            this.submitTag2="add"
            this.upfileList2=[]
        },
        // 详情上传图片成功
        updateDetailSuccess2(response, file, fileList){
            
            this.uploadNum2++
            if(this.uploadNum2==this.imgListLength2){
                let wdgIesDtsList=[]
                // let obj={"imgName":"","wdgIesId":""}
                // for(let i=0;i<fileList.length;i++){
                //     wdgIesDtsList.push(obj)
                // }

                
                let fileKeys=[]
                
                for(let i=0;i<fileList.length;i++){
                    fileKeys.push(fileList[i].response.key)
                    
                    let obj={"imgName":"","wdgIesId":this.table2pmas.wdgIesId}
                    obj.imgName=fileList[i].response.key
                    wdgIesDtsList.push(obj)
                }

                console.log("要传给后端的key集合",wdgIesDtsList)
                

                if(this.submitTag2=="add"){

                    this.addServer2({
                        wdgIesDtsList:JSON.stringify(wdgIesDtsList),
                    })
                }
                if(this.submitTag2=="change"){

                    this.detailsUpPamas.imgName=fileKeys[0]

                    console.log("`````````````````````````````",this.detailsUpPamas)
                    
                    this.upServer2(this.detailsUpPamas)
                }
                
            }
        } ,

        // 新增一条的接口
        addServer2(pamas){
            
            console.log("要查询详情的参数",this.table2pmas)
            
            postRequest(url.wdgIesDtsInsert, pamas).then(data=> {
                this.uploadNum2=0
                this.submitTag2="add"
                this.dialogVisible=false
                
                console.log("上传到服务器成功返回22222",)
                this.upfileList2=[]
                if(!getErr(data.data.code,data.data.message)) {
                    return
                }
                this.initData2(this.table2pmas)

                
            });  
        },

        // 更新一条的接口
        upServer2(pamas){
            postRequest(url.wdgIesDtsUpdate, pamas).then(data=> {
                this.uploadNum2=0
                this.submitTag2="add"
                console.log("上传到服务器成功返回",this.table2pmas)
                if(!getErr(data.data.code,data.data.message)) {
                    return
                }
                this.initData2(this.table2pmas)
                this.upfileList2=[]
                
            });  
        },


        // 上传详情图片提交
        subDetailForm(){
            
            this.$refs.uploadimg2.submit();
        },

        // 上传图片之前
        beforeUpload(file){
        let dates= new Date()

         return  this.qiniu.key=file.uid
           
      
        },
        // 详情图片上传改变
        handleChange2(file, fileList) {
            this.imgListLength2=fileList.length
            console.log("显示图的长度",this.imgListLength2)
            this.isChangeImg2=true
        },
        // 详情图片修改
        changeDetail(index, rows){
            this.submitTag2='change'

        
            this.upfileList2=[{url:this.qiniu.showUrl+rows[index].imgName}]
            
            this.detailsUpPamas={
                imgName:rows[index].imgName,
                id:rows[index].id,
                oldImgName:rows[index].imgName
            }
        },

        // 显示详情弹窗
        showDetail(index, rows){
            
            this.dialogVisible2=true;
            this.table2pmas={
                wdgIesId:rows[index].id,
                "pageNum":this.currentPage,
                "pageSize":"999",
            }
            this.initData2(this.table2pmas)

        },
        // 详情单删除
        deleteDetailRow(index, rows) {

           
        console.log("deleteRow",rows[index].id,rows[index].imgName)
        this.$confirm('是否删除?', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
            }).then(() => {

                postRequest(url.wdgIesDtsDelete, {
                    ids:rows[index].id,
                    imgName:rows[index].imgName,
                }).then(data=> {
                    console.log("删除后打印的数据",data)
                    if(!getErr(data.data.code,data.data.message)) {
                        return
                    }
                    this.initData2(this.table2pmas)//查询所有  
                    this.$message({
                        type: 'success',
                        message: '删除成功'
                    });        
                                    
                });    
                       
            }).catch(() => {
                this.$message({
                type: 'info',
                message: '已取消删除'
                });          
            });
   
        
        
        },

        //详情 批量删除
        deletAll2(){
            console.log("查看表单内的选中的条数",this.multipleSelection2)
            let arrId=[];
            let arrPictures=[];
            for(let i=0;i<this.multipleSelection2.length;i++){
                arrId.push(this.multipleSelection2[i].id)
                arrPictures.push(this.multipleSelection2[i].imgName)

            }




            if(arrId.length==0){
                this.$message({
                    type: 'success',
                    message: '请选择后删除'
                });
                return
            }

                this.$confirm('是否删除?', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    postRequest(url.wdgIesDtsDelete, {
                        ids:arrId,
                        imgName:arrPictures,
                        }).then(data=> {
                        console.log("删除后打印的数据",data)
                        if(!getErr(data.data.code,data.data.message)) {
                            return
                        }
                        this.initData2(this.table2pmas)//查询所有     
                        this.$message({
                            type: 'success',
                            message: '删除成功'
                        });        
                                
                    });    
                       
                    }).catch(() => {
                        this.$message({
                            type: 'info',
                            message: '已取消删除'
                        });          
                });
           

        }, 

        // 多选操作改变事件
        handleSelectionChange2(val) {
            this.multipleSelection2 = val;
        },

        /**************************************************以上为详情******************************************************************************/ 




        handleChange(file, fileList) {
            this.imgListLength=fileList.length
            console.log("显示图的长度",this.imgListLength)
            this.isChangeImg=true
        },


        // 上传图片成功
        updateDetailSuccess(response, file, fileList){

            this.uploadNum++
            if(this.uploadNum==this.imgListLength){
                let fileKeys=[]
                for(let i=0;i<fileList.length;i++){
                    fileKeys.push(fileList[i].response.key)
                }
                

                console.log("要传给后端的key集合",fileKeys)
                if(this.submitTag=="add"){
                    this.addServer({
                        imgName:fileKeys[0],
                    })
                }
                if(this.submitTag=="change"){
                    this.oldPamas.imgName=fileKeys[0]

                    console.log("`````````````````````````````",this.oldPamas)
                    
                    this.upServer(this.oldPamas)
                }
                
            }
        } ,

        // 新增一条的接口
        addServer(pamas){
            postRequest(url.wdgIesInsert, pamas).then(data=> {
                this.uploadNum=0
                
                this.dialogVisible=false
                console.log("上传到服务器成功返回",data)
                if(!getErr(data.data.code,data.data.message)) {
                    return
                }
                this.initData({
                    pageSize:"10",
                    pageNum:this.currentPage,
                })
                this.initQiniu()
                
            });  
        },

        // 更新一条的接口
        upServer(pamas){
            postRequest(url.wdgIesUpdate, pamas).then(data=> {
                this.uploadNum=0
                this.dialogVisible=false
                console.log("上传到服务器成功返回",data)
                if(!getErr(data.data.code,data.data.message)) {
                    return
                }
                this.initData({
                    pageSize:"10",
                    pageNum:this.currentPage,
                })
                
            });  
        },
        // 新增酒店
        
        addMost(){
            
            this.dialogVisible=true;
            this.upfileList=[]
            this.submitTag="add"
            this.$nextTick(() => {
                this.$refs.uploadimg.clearFiles()
            });
            
        },
        //提交
        subPicForm(){

        if(this.submitTag=="change" && !this.isChangeImg){
            
            this.oldPamas.oldImgName=""

            console.log("888888888888888888",this.oldPamas)
            this.upServer(this.oldPamas)
        }
        this.$refs.uploadimg.submit();
                    


        },


        //弹窗出现 修改
        changeRow(index, rows){
            this.isChangeImg=false
            this.dialogVisible=true;
            this.submitTag="change"
            this.changeId=rows[index].id;
            this.changeIndex=index;

            this.$nextTick(() => {
            this.ruleForm={
                title : rows[index].title,


            }
            });
            
            this.oldPamas={
                imgName:rows[index].imgName,

                oldImgName:rows[index].imgName,
                
                id:rows[index].id
            }
            this.upfileList=[{url:this.qiniu.showUrl+rows[index].imgName}]
            

        },
        // 单删除
        deleteRow(index, rows) {

           
        console.log("deleteRow",rows[index].id,rows[index].bannerUrl)
        this.$confirm('是否删除?', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
            }).then(() => {

                postRequest(url.wdgIesDelete, {
                    ids:rows[index].id,
                    imgName:rows[index].imgName,
                }).then(data=> {
                    console.log("删除后打印的数据",data)
                    this.dialogVisible=false
                    if(!getErr(data.data.code,data.data.message)) {
                        return
                    }
                    this.initData(this.tableData) //查询所有  
                    this.$message({
                        type: 'success',
                        message: '删除成功'
                    });        
                                    
                });    
                       
            }).catch(() => {
                this.$message({
                type: 'info',
                message: '已取消删除'
                });          
            });
   
        
        
        },

        // 批量删除
        deletMost(){
            console.log("查看表单内的选中的条数",this.multipleSelection)
            let arrId=[];
            let arrPictures=[];
            for(let i=0;i<this.multipleSelection.length;i++){
                arrId.push(this.multipleSelection[i].id)
                arrPictures.push(this.multipleSelection[i].imgName)

            }




            if(arrId.length==0){
                this.$message({
                    type: 'success',
                    message: '请选择后删除'
                });
                return
            }

                this.$confirm('是否删除?', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    postRequest(url.wdgIesDelete, {
                        ids:arrId,
                        imgName:arrPictures,
                        }).then(data=> {
                        console.log("删除后打印的数据",data)
                        this.dialogVisible=false
                        if(!getErr(data.data.code,data.data.message)) {
                            return
                        }
                        this.initData(this.tableData) //查询所有    
                        this.$message({
                            type: 'success',
                            message: '删除成功'
                        });        
                                
                    });    
                       
                    }).catch(() => {
                        this.$message({
                            type: 'info',
                            message: '已取消删除'
                        });          
                });
           

        }, 

        uploadFile(file){
            this.formDate.append('file', file.file);
        },

        // 点击弹窗的叉号
        closeDialog(){

        },

        goSearch(){

            console.log("this.tableData",this.tableData)
            this.initCitySelct(this.tableData)
            
        },

        initQiniu(){
            postRequest(url.initGetQiniuConfig, {}).then(data=> {
                if(!getErr(data.data.code,data.data.message)) {
                    return
                }

                console.log("七牛初始化配置",data)
                this.qiniu={
                    showUrl:data.data.data.domain,
                    token:data.data.data.uploadToken,
                }
                        
            });     
        },

        initData(pamas){
            postRequest(url.wdgIesGetWdgIesList, pamas).then(data=> {

                if(!getErr(data.data.code,data.data.message)) {
                    return
                }
                console.log("初始化数据1111",data.data.data)
                let datas=data.data.data;
                this.tableList=datas.list
                this.total= datas.total        
                // this.navigatepageNums=datas.navigatepageNums      
                this.currentPage=datas.pageNum 
                        
            });     
        },

        initData2(pamas){
            postRequest(url.wdgIesDtsGetWdgIesDtsList, pamas).then(data=> {
                if(!getErr(data.data.code,data.data.message)) {
                    return
                }

                console.log("初始化数据2222222",data.data.data)
                let datas=data.data.data;
                this.tableList2=datas.list

                        
            });     
        },

        initCitySelct(){
            postRequest(url.cityGetCityListByOpen, {}).then(data=> {

                if(!getErr(data.data.code,data.data.message)) {
                    return
                }
                console.log("初始化城市select",data)
                this.cityList=data.data.data
                let allcityO={id:"",provinceName:"全部城市"}
                this.cityList.unshift(allcityO)
                console.log("初始化城市select2",this.cityList)        
            });     
        },

        // 多选操作改变事件
        handleSelectionChange(val) {
            this.multipleSelection = val;
        },
        // f分页
        handleSizeChange(val) {
            console.log(`每页 ${val} 条`);
        },
        handleCurrentChange(val) {
            this.initData({
                pageSize:"10",
                pageNum:val,
            })
        },
    },

    computed:{
        tableData(){
            return {
                "pageNum":this.currentPage,
                "pageSize":"10",
                // "userId":localStorage.getItem('ms_userId'),
                // "likeName":this.search,
                // "cityId":this.formInline.cityV
            }
        },
    },

    created(){

        this.initData({
            pageSize:"10",
            pageNum:this.currentPage,
        })
        this.initQiniu()
    },
}
</script>

<style scoped>
.demo-ruleForm{
    display: flex;
    flex-wrap: wrap;
    width: 100%;
}
.demo-ruleForm .el-form-item{
    width: 93%;
    margin-left: 3%
}
.demo-ruleForm .el-form-item:nth-child(2n){
    
}
</style>

