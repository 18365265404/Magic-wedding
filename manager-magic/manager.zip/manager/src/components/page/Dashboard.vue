<template>
        <div>
            <div style="overflow: hidden;">
                <quill-editor 
                v-model="content" 
                ref="myQuillEditor" 
                style="min-height:200px ;"
                :options="editorOption" 
                @blur="onEditorBlur($event)" @focus="onEditorFocus($event)"
                @change="onEditorChange($event)">
                </quill-editor>
            </div>


        

            <el-button class="pop-btn ipt-style" :plain="true"  type="danger" @click="submitAdd()" style="width:100%;">确认添加</el-button>


            <div>
            {{mycontent}}
            </div>
        </div>


    
</template>

<script>
import url from '../../utils/url';
import {getCookie} from '../../utils/utils';
import {postRequest,uploadFileRequest} from '../../utils/api';
import { quillEditor } from 'vue-quill-editor'

  export default {
    data() {
      return {
          content:null,
          editorOption:{
         
                    placeholder: '编辑内容...'
          },
        mycontent:''

      };
    },


    methods: {

        onEditorBlur(){//失去焦点事件
        },
        onEditorFocus(){//获得焦点事件
        },
        onEditorChange(){//内容改变事件
        },
        submitAdd(){
            postRequest('test/insert',{
            content:this.content
            } ).then(data=> {
                console.log("富文本插入",data)
            })
        }
    },



    created(){
        
        postRequest('test/getTest',{
            content:this.content
        } ).then(data=> {
            console.log("富文本插入",data)
            this.mycontent=data.data.data.content
        })
    }
  }
</script>