import {getImgUrl} from './getImgUrl';

export default{
    getImgUrl
}