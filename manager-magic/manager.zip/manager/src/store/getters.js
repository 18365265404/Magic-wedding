export default {

  siderState:(state)=>{
    return state.siderState;
  },
  initFoot:(state)=>{
    return state.initFoot;
  },
  count:(state)=>{
    return state.count;
  },
  bFoot:(state)=>{
    return state.bFoot;
  },
  bLoading:(state)=>{
    return state.bLoading;
  }
};
 