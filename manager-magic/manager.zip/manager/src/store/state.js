export default {
  siderState:[],
  initFoot:false,
  count:0,
  bLoading:false,
  bFoot:true,
};
 